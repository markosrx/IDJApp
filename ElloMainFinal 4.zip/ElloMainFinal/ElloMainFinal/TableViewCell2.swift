//
//  TableViewCell2.swift
//  ElloMainFinal
//
//  Created by MacBook Air on 12/7/17.
//  Copyright © 2017 MacBook Air. All rights reserved.
//

import UIKit

class TableViewCell2: UITableViewCell {

    
    @IBOutlet var CollectionView2: UICollectionView!

    @IBOutlet var MenuLine1: UIView!
    @IBOutlet var MenuLine2: UIView!{
        didSet{
            MenuLine2.isHidden = true
        }
    }
    @IBOutlet var MenuLine3: UIView!{
        didSet{
            MenuLine3.isHidden = true
        }
    }
    var Btn1Active = true
    var Btn2Active = false
    var Btn3Active = false
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    
    @IBAction func btnNewestVideo(_ sender: Any) {
        
        Btn2Active = false
        Btn3Active = false
        
        MenuLine1.isHidden = false
        MenuLine2.isHidden = true
        MenuLine3.isHidden = true
        CollectionView2.delegate = self
        CollectionView2.dataSource = self
        CollectionView2.tag = 1
        CollectionView2.reloadData()
        //CollectionView2.contentOffset.x = 15
        //CollectionView2.contentInset = UIEdgeInsetsMake(20, 15, 15, 0)
        if Btn1Active == false{
            CollectionView2.scrollToItem(at: IndexPath(row: 0 ,section: 0), at: .left, animated: false)
            Btn1Active = true
        }
    }
    
    @IBAction func btnTrending(_ sender: Any) {
       
        Btn1Active = false
        Btn3Active = false
        
        MenuLine1.isHidden = true
        MenuLine2.isHidden = false
        MenuLine3.isHidden = true
        CollectionView2.delegate = self
        CollectionView2.dataSource = self
        CollectionView2.tag = 2
        CollectionView2.reloadData()
        if Btn2Active == false{
            CollectionView2.scrollToItem(at: IndexPath(row: 0 ,section: 0), at: .left, animated: false)
            Btn2Active = true
        }
    }
    
    @IBAction func btnEmerging(_ sender: Any) {
        
        Btn1Active = false
        Btn2Active = false
        
        MenuLine1.isHidden = true
        MenuLine2.isHidden = true
        MenuLine3.isHidden = false
        CollectionView2.delegate = self
        CollectionView2.dataSource = self
        CollectionView2.tag = 3
        CollectionView2.reloadData()
        if Btn3Active == false{
            CollectionView2.scrollToItem(at: IndexPath(row: 0 ,section: 0), at: .left, animated: false)
            Btn3Active = true
        }
    }
    
}
extension TableViewCell2: UICollectionViewDataSource, UICollectionViewDelegate{
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        let num = collectionView.tag
        if num == 1{
            return 10
        }else if num == 2{
            return 7
        }else if num == 3{
            return 8
        }
        return 7
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let btn = collectionView.tag
        if btn == 1 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Slider", for: indexPath) as! CollectionViewCell
            cell.configure2(a: indexPath)
        return cell
        }
        else if btn == 2 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Slider", for: indexPath) as! CollectionViewCell
            cell.btnConfigure1(a: indexPath)
        return cell
        }
        else if btn == 3 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Slider", for: indexPath) as! CollectionViewCell
            cell.btnConfigure2(a: indexPath)
            return cell
        }
        else{
            print("Neka greska nema vise dugmica")
        }
        
        return CollectionViewCell()
    }
    
    
    
    
    
    
    
    
}
