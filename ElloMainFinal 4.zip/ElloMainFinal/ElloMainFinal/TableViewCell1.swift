//
//  TableViewCell1.swift
//  ElloMainFinal
//
//  Created by MacBook Air on 12/7/17.
//  Copyright © 2017 MacBook Air. All rights reserved.
//

import UIKit

class TableViewCell1: UITableViewCell {

    
    @IBOutlet var CollectionView1: UICollectionView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
