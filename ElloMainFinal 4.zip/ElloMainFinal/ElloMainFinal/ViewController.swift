//
//  ViewController.swift
//  ElloMainFinal
//
//  Created by MacBook Air on 12/7/17.
//  Copyright © 2017 MacBook Air. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var sideMenuConstraint: NSLayoutConstraint!
    var sideMenuOpen = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.addObserver(self, selector: #selector(toggleSideMenu), name: NSNotification.Name("ToggleSideMenu"), object: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    @objc func toggleSideMenu() {
        if sideMenuOpen{
            sideMenuOpen = false
            sideMenuConstraint.constant = 0
        }else{
            sideMenuOpen = true
            sideMenuConstraint.constant = 188
        }
        UIView.animate(withDuration: 0.3) {
            self.view.layoutIfNeeded()
        }
    }

}

