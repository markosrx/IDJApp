//
//  File.swift
//  ElloMainFinal
//
//  Created by MacBook Air on 12/8/17.
//  Copyright © 2017 MacBook Air. All rights reserved.
//

import Foundation


let Playlists = ["Aleksandra Mladenovic", "Aleksandra Prijovic", "SHA", "Tea Tairovic", "Teodora", "Beca Fantastik", "THCF"]
