//
//  SideMenuVC.swift
//  ElloMainFinal
//
//  Created by MacBook Air on 12/9/17.
//  Copyright © 2017 MacBook Air. All rights reserved.
//

import UIKit

class SideMenuVC: UITableViewController {

    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(indexPath.row)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        

    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
