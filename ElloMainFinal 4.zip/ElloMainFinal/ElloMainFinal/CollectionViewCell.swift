//
//  CollectionViewCell.swift
//  ElloMainFinal
//
//  Created by MacBook Air on 12/7/17.
//  Copyright © 2017 MacBook Air. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet var PlaylistName: UILabel!
    
    
    func configure(a: IndexPath) {
        let image = UIImage(named: "slika" + String(a.item))
        imageView.image = image
        setNeedsLayout()
        layoutIfNeeded()
        imageView.layer.cornerRadius = 11        
        imageView.clipsToBounds = true
    }
    
    
    @IBOutlet var imageView2: UIImageView!
    
    func configure2(a: IndexPath) {
        let image = UIImage(named: "img" + String(a.item))
        imageView2.image = image
        setNeedsLayout()
        layoutIfNeeded()
        imageView2.layer.cornerRadius = 11
        imageView2.clipsToBounds = true
    }
    
    //FUNKCIJE ZA DUGMICE
    func btnConfigure1(a: IndexPath) {
        let image = UIImage(named: "idj" + String(a.item))
        imageView2.image = image
        setNeedsLayout()
        layoutIfNeeded()
        imageView2.layer.cornerRadius = 11
        imageView2.clipsToBounds = true
    }
    
    func btnConfigure2(a: IndexPath) {
        let image = UIImage(named: "tunes" + String(a.item))
        imageView2.image = image
        setNeedsLayout()
        layoutIfNeeded()
        imageView2.layer.cornerRadius = 11
        imageView2.clipsToBounds = true
    }
    
    func playlst(a: IndexPath) {
        let image = UIImage(named: "play" + String(a.item))
        imageView2.image = image
        let text = Playlists[a.item]
        PlaylistName.text = text
        setNeedsLayout()
        layoutIfNeeded()
        imageView2.layer.cornerRadius = 11
        imageView2.clipsToBounds = true
    }
}
