//
//  TableViewController.swift
//  ElloMainFinal
//
//  Created by MacBook Air on 12/7/17.
//  Copyright © 2017 MacBook Air. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController {

    
    @IBAction func onMoreTapped(){
        print("TOGGLE SIDE MENU")
        NotificationCenter.default.post(name: NSNotification.Name("ToggleSideMenu"), object: nil)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        addNavBarImage()
    }
    // Funkcija za stavljanje slike umesto title u status baru
    func addNavBarImage() {
        let navController = navigationController!
        
        let image = #imageLiteral(resourceName: "ELLO-Logo_02 copy")
        let imageView = UIImageView(image: image)
       
        let bannerWidth = navController.navigationBar.frame.size.width
        let bannerHeight = navController.navigationBar.frame.size.height
        
        let bannerX = bannerWidth / 2 - image.size.width / 2
        let bannerY = bannerHeight / 2 - image.size.height / 2
        
        
        imageView.frame = CGRect(x: bannerX, y: bannerY, width: bannerWidth, height: bannerHeight)
        imageView.contentMode = .scaleAspectFit
        
        navigationItem.titleView = imageView
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
extension TableViewController {
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 5
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0, 1, 2, 3, 4: return 1
        default: return 0
        }
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch indexPath.section {
        case 0:
            let cell = tableView.dequeueReusableCell(withIdentifier: "TableCell1", for: indexPath) as! TableViewCell1
            cell.CollectionView1.dataSource = self
            cell.CollectionView1.delegate = self
            
            cell.CollectionView1.tag = indexPath.section
            return cell
        case 1:
            let cell = tableView.dequeueReusableCell(withIdentifier: "TableCell2", for: indexPath) as! TableViewCell2
            cell.CollectionView2.dataSource = self
            cell.CollectionView2.delegate = self
        
            cell.CollectionView2.tag = indexPath.section
            return cell
        case 2:
            let cell = tableView.dequeueReusableCell(withIdentifier: "TableCell3", for: indexPath) as! TableViewCell3
            cell.CollectionView3.dataSource = self
            cell.CollectionView3.delegate = self
            
            cell.CollectionView3.tag = indexPath.section
            return cell
        case 3:
            let cell = tableView.dequeueReusableCell(withIdentifier: "TableCell4", for: indexPath) as! TableViewCell4
            cell.CollectionView4.dataSource = self
            cell.CollectionView4.delegate = self
            
            cell.CollectionView4.tag = indexPath.section
            return cell
        case 4:
            let cell = tableView.dequeueReusableCell(withIdentifier: "TableCell5", for: indexPath) as! TableViewCell5
            cell.CollectionView5.dataSource = self
            cell.CollectionView5.delegate = self
            
            cell.CollectionView5.tag = indexPath.section
            return cell
        default:
            return UITableViewCell()
        }
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        switch indexPath.section {
        case 0: return 240
        case 1: return 200
        case 2: return 200
        case 3: return 200
        case 4: return 200
        default: return 0
        }
    }
    
//    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
//
//        if indexPath.section == 0 {
//            if let cell = cell as? TableViewCell1 {
//                cell.CollectionView1.dataSource = self
//                cell.CollectionView1.delegate = self
//                cell.CollectionView1.reloadData()
//            }
//            else{
//                print("nesto ne valja")
//            }
//        }
//  }
    
}

extension TableViewController: UICollectionViewDataSource , UICollectionViewDelegate{
    
    //DATA-SOURCE METHODS
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
       
        let datasourceIndex = collectionView.tag
        if datasourceIndex == 0{
            return 5
        }else if datasourceIndex == 1{
            return 10
        }
        else if datasourceIndex == 2{
            return 7
        }
        else if datasourceIndex == 3{
            return 7
        }
        else if datasourceIndex == 4{
            return Playlists.count
        }
        else {
            
            print("ovo je druga celija")
        }
        
        return 10
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        
        let datasourceIndex = collectionView.tag
        if datasourceIndex == 0{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Carousel", for: indexPath) as! CollectionViewCell
            cell.configure(a: indexPath)
            return cell
        }else if datasourceIndex == 1{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Slider", for: indexPath) as! CollectionViewCell
            cell.configure2(a: indexPath)
            return cell
        }else if datasourceIndex == 2{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SliderCountry", for: indexPath) as! CollectionViewCell
            cell.btnConfigure1(a: indexPath)
            return cell
        }else if datasourceIndex == 3{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SliderArtist", for: indexPath) as! CollectionViewCell
            cell.btnConfigure2(a: indexPath)
            return cell
        }else if datasourceIndex == 4{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SliderPlaylists", for: indexPath) as! CollectionViewCell
            cell.playlst(a: indexPath)
            return cell
        }
        
        return CollectionViewCell()
        
    }
}



