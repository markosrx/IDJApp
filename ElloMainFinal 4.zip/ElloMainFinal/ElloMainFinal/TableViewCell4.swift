//
//  TableViewCell4.swift
//  ElloMainFinal
//
//  Created by MacBook Air on 12/8/17.
//  Copyright © 2017 MacBook Air. All rights reserved.
//

import UIKit

class TableViewCell4: UITableViewCell {

    
    @IBOutlet var CollectionView4: UICollectionView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
